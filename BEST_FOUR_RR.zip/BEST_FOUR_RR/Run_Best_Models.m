% Best Four Rainfall-Runoff Models by T. Benkaci & N. Dechemi
% email: Benktar@gmail.com
close all; clc; clear all; %mise a jour de toutes les variables 
global x Nash P E Qobs Qsim param

data=load('File_Data.txt'); % File data in text format, Do not change Name of this File only copy and paste your Data
P = data(:,1);   % First input-Column: Daily Precipitation (mm/d)
E = data(:,2);   % Second input-Column: Daily Evapotranspiration (mm/d)
Qobs=data(:,3);  % Third input-Column: Observed Daily Discharge :Target (in m3/s)
param=load('parameters.txt');
x0=xlsread('Initial_Models.xlsx','feuil1'); % Initial Parameters for each Model
%Change These Initial Parameters for Otheres Basins

Sup=param(1); % First Parameter : Area of Basin in Km2 ro convert Qsim(mm) to Qsim (m3/s)
%KK=[param(2):param(3)];  Period of Calibration (Day)
%KT=[param(4):param(5)];  Period of Test (Day)

Best_Models  % Main File to excecute others Subroutines
% After Optimisation Sim_Best file Simulates New Runoff from File_Sim 
% Note : Do not change Name of this File only copy and paste your Data.
%P1 = data1(:,1);   % First input-Column: Daily Precipitation (mm/d)
%E1= data1(:,2);   % Second input-Column: Daily Evapotranspiration (mm/d)
%  Dr  T. Benkaci.